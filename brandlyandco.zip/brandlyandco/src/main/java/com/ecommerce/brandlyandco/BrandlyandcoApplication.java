package com.ecommerce.brandlyandco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrandlyandcoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrandlyandcoApplication.class, args);
	}

}
