package com.ecommerce.brandlyandco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrandlyandcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
