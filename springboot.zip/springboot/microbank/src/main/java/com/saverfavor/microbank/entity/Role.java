package com.saverfavor.microbank.entity;

public enum Role {

    ADMIN,
    USER,
}
