package com.saverfavor.microbank.security;

import com.saverfavor.microbank.jwt.JwtAuthenticationFilter;
import com.saverfavor.microbank.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class  SecurityConfig {

    private final UserService userService;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        return
                http

                        .csrf(AbstractHttpConfigurer::disable)
                        .cors(Customizer.withDefaults())
                        .authorizeHttpRequests(

                                req ->
                                        req.requestMatchers("/login",
                                                        "/api/userRegistration","/activate/**","/api/userRegistration/update/{id}",
                                                        "/api/userRegistration/get",
                                                        "/api/nominee/get","/api/nominee/get/{id}","/api/nominee/save",
                                                        "/api/nominee/updateNominee/{id}",


                                                        "/api/Balance/save","/api/Balance/get","/api/Balance/get/{id}",
                                                        "/api/Balance/getByUser/{userId}",

                                                        "/api/loan/save", "/api/loan/get/{id}" ,"/api/loan/get","/api/loan/getByUser/{userId}",

                                                        "/api/Referral/save","/api/Referral/get","/api/Referral/getByUser/{id}" ,
                                                        "/api/Referral/get/{id}"
                                                ,"/api/notifications/sendToAll","/api/notifications/sendToUser/{userId}","/ws/**",
                                                        "/all/messages","/private",

                                                        "/api/transactions/save","/api/confirm-otp","/api/Withdrawal/verify",
                                                        "/api/withdraw/CryptoDeposit/save",
                                                        "/api/transactions/get","/api/transactions/getByUser/{userId}",
                                                        "/api/transactions/{id}","/api/CryptoDeposit/get",
                                                        "/api/CryptoDeposit/{id}","/api/CryptoDeposit/getByUser/{userId}",
                                                "/api/ProfitWithdrawalBank/get","/api/ProfitWithdrawalBank/{id}"

                                                ,"/api/ProfitWithdrawalBank/getByUser/{userId}","/api/ProfitWithdrawalBank/save",


                                                        "/api/CryptoProfit/get", "/api/CryptoProfit/{id}",
                                                        "/api/CryptoProfit/getByUser/{userId}","/api/withdraw/CryptoProfit/save"


                                                ,"/api/ProfitWithdrawalBank/verify"
                                                ,"/api/EmiPay/save"

                                                )
                                                .permitAll()


                                                .requestMatchers( "**"


                                                        )
                                                .hasAuthority("USER")


                                                .requestMatchers(






                                                        "/api/nominee/updateNominee/{id}","/ws/**","/all/messages","/private")
                                                .hasAuthority("ADMIN")


                        )
                        .userDetailsService(userService)
                        .sessionManagement(
                                session ->
                                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                        )
                        .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                        .build();


    }



    @Bean
    public PasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }


    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }


    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("http://localhost:6160", "http://localhost:6161"));  // Add allowed origins
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(List.of("Authorization", "Cache-Control", "Content-Type"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);  // Apply CORS settings to all endpoints
        return source;
    }


}
