package com.saverfavor.microbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrobankApplicationTests {

	@Test
	void contextLoads() {
	}

}
