package com.saverfavor.microbank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.saverfavor.microbank.entity.Balance;

import java.util.List;

@Repository
public interface BalanceRepository extends JpaRepository<Balance, Integer> {
    List<Balance> findByUserRegistrationId(long userId);
}